define([], function() {

	// Local Variables
	var TYPES = {PENCIL: 0, SPRAY: 1, TEXT: 2};
	var prevX, currX, prevY, currY;
	var paintColor = "black", paintType;
	var sprayInterval, sprayImg, sprayAngle = 0, sprayRadius = 10;
	var canvas, ctx;
	var inDraw;
	var textBox;
	var localSketches = [];
	var buttons = {};

	function BurntCanvas() {}

	BurntCanvas.prototype.lightMatch = function() {
		//'https://zackargyle.firebaseIO.com/BurntCanvas'
	};

	BurntCanvas.prototype.extinguish = function() {

	}

	function setCanvas() {
		  canvas = document.getElementById("BurntCanvas");
	    canvas.width  = window.innerWidth;
	    canvas.height = window.innerHeight;
	    ctx = canvas.getContext("2d");
	    ctx.font = "16px Arial";
	    ctx.lineWidth = 2;

	    canvas.addEventListener("mouseover", function (e) {
	    	canvas.style.cursor = "pointer";
	    });
	    canvas.addEventListener("mousemove", function (e) {
	        findXY('move', e)
	    }, false);
	    canvas.addEventListener("mousedown", function (e) {
	        findXY('start', e)
	    }, false);
	    canvas.addEventListener("mouseup", function (e) {
	        findXY('stop', e)
	    }, false);
	};
	setCanvas();

	function setImages() {
		wallImg = new Image();
	  wallImg.src = 'img/wall.png';
	  wallImg.onload = function(){
	    ctx.drawImage(wallImg, 0, 0, canvas.width, canvas.height);
	  }
	  sprayImg = new Image();
	  sprayImg.src = 'img/splatter.png';
	}
	setImages();

	function setChoices() {
		var container = document.createElement("div");

		setButtons(container);
		setTextBox();

		var colors = ["green", "blue", "red", "black", "white"];
		for (var i = 0; i < colors.length; i++) {
			createColorChoice(colors[i], container);
		}
		
		document.getElementById("canvasChoices").appendChild(container);
	};
	setChoices();

	function saveContext(text) {
		var data = {
			x: currX,
			y: currY,
			color: paintColor,
			type: paintType
		};

		if (data.type === TYPES.PENCIL) {
			data.prevX = prevX;
			data.prevY = prevY;
		} else if (data.type === TYPES.SPRAY) {
			data.angle = sprayAngle;
		} else if (paintType === TYPES.TEXT) {
			data.text = text;
		}

		localSketches.push(data);
		console.log(localSketches);
	}

	function draw(data) {
	    ctx.beginPath();
	    ctx.moveTo(prevX, prevY);
	    ctx.lineTo(currX, currY);
	    ctx.strokeStyle = paintColor;
	    ctx.stroke();
	    ctx.closePath();
	    saveContext();
	};

	function spray() {
		sprayAngle += 41;
		if (sprayAngle > 360) sprayAngle -=360;
		ctx.save();
		ctx.translate(currX, currY);
		ctx.rotate(sprayAngle * Math.PI / 180);
		ctx.translate(-currX-sprayRadius, -currY-sprayRadius);
		ctx.drawImage(sprayImg, currX, currY, sprayRadius*2, sprayRadius*2);
		ctx.restore();
		saveContext();
	};

	function startSpraying(position) {
		sprayInterval = setInterval(spray, 100);
	};
  
	function finishSpraying(position) {
		clearInterval(sprayInterval);
	};

	function writeText(text) {
		ctx.fillStyle = paintColor;
		ctx.font = '15px sans-serif';
	  ctx.fillText(text, currX + 5, currY + 20);
	  saveContext(text);
	}

	function requestText() {
		textBox.style.left = currX + 'px';
		textBox.style.top  = currY + 'px';
		textBox.style.color = paintColor;
		document.body.appendChild(textBox);
	};

	function moveText() {
		textBox.style.left = currX + 'px';
		textBox.style.top  = currY + 'px';
	}

	function setXY(e) {
		prevX = currX;
  	prevY = currY;
  	currX = e.clientX - canvas.offsetLeft;
  	currY = e.clientY - canvas.offsetTop;
	}

	function findXY(mouseMove, e) {
		if (mouseMove == 'stop') {
    	if (paintType === TYPES.SPRAY) {
    		finishSpraying();
    	}
    	inDraw = false;
    } else if (mouseMove == 'move') {
    	if (inDraw) {
     	  	setXY(e);
        	if (paintType === TYPES.PENCIL) {
   					draw();
        	} else if (paintType === TYPES.TEXT) {
		    		moveText();
		    	}
			}
		} else if (mouseMove == 'start') {
    	setXY(e);
     	if (paintType === TYPES.SPRAY) {
     		startSpraying();
     	} else if (paintType === TYPES.TEXT) {
     		requestText();
     	}
     	inDraw = true;
    }
	}

	function undo() {
		var sketch = localSketches.unshift();
		if (sketch.type === TYPES.SPRAY) {
			for (var i = 0; i < 4; i++) {
				localSketches.unshift();
			}
		}
		for (var i = 0; i < localSketches.length; i++) {
			var sketch = localSketches[i];
			if (sketch.type === TYPES.PENCIL) draw();
			else if (sketch.type === TYPES.SPRAY) draw();
		}
	};

	function highlight(type) {
		buttons["SPRAY"].style.backgroundColor = (type === TYPES.SPRAY) ? "hsl(0,0%,75%)" : "white";
		buttons["PENCIL"].style.backgroundColor = (type === TYPES.PENCIL) ? "hsl(0,0%,75%)" : "white";
		buttons["TEXT"].style.backgroundColor = (type === TYPES.TEXT) ? "hsl(0,0%,75%)" : "white";
	}

	function setToSpray() {
		paintType = TYPES.SPRAY;
		highlight(TYPES.SPRAY);
	}

	function setToSketch() {
		paintType = TYPES.PENCIL;
		highlight(TYPES.PENCIL);
	}

	function setToText() {
		paintType = TYPES.TEXT;
		highlight(TYPES.TEXT);
	}

	function setButtons(container) {
		var button_list = [
			{name: "UNDO", fn: undo},
			{name: "PENCIL", fn: setToSketch},
			{name: "SPRAY", fn: setToSpray},
			{name: "TEXT", fn: setToText}
		];

		for (var i = 0; i < button_list.length; i++) {
			var button = button_list[i];
			var node = document.createElement("div");
			node.style.backgroundImage = "url(img/" + button.name + ".png)";
			node.className = "choice choiceImg";
			node.id = button.name;
			node.addEventListener("click", button.fn);
			container.appendChild(node);
			buttons[button.name] = node;
		}

		setToSketch();
	}

	function createColorChoice(color, container) {
		var node = document.createElement("div");
		node.className = "choice";
		node.style.backgroundColor = color;
		node.addEventListener("click", function() {
			paintColor = color;
		});
		container.appendChild(node);
	};

	function setTextBox() {
		textBox = document.createElement("input");
		textBox.id = "requestText";
		textBox.setAttribute("autofocus", true);
		textBox.addEventListener("mouseup", function() {
			inDraw = false;
		});
		textBox.addEventListener("keydown", function(e) {
			if (e.keyCode === 13) {
				writeText(textBox.value);
				textBox.value = "";
				textBox.parentNode.removeChild(textBox);
			}
		});
	};

	return new BurntCanvas();

});

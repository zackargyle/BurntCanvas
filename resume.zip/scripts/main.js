require(["BurntCanvas", "SkillCanvas"], function(BurntCanvas, SkillCanvas) {
    BurntCanvas.lightMatch();
    SkillCanvas.start();
});